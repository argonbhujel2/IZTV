package com.iztv.ui.youtube

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.iztv.R
import com.iztv.utils.Prefs

class YouTubeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_youtube)

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }

        val openAppBtn = findViewById<Button>(R.id.btnOpenYoutube)
        openAppBtn.setOnClickListener { launchYouTubeApp() }
        openAppBtn.requestFocus()

        findViewById<Button>(R.id.btnOpenVideo).setOnClickListener {
            val videoId = Prefs(this).youtubeVideoId
            if (videoId.isNotBlank()) {
                openYouTubeVideo(videoId)
            } else {
                Toast.makeText(this, "Set a YouTube Video ID in Test Mode first", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun launchYouTubeApp() {
        try {
            // Official YouTube Leanback / TV package
            val intent = packageManager.getLaunchIntentForPackage("com.google.android.youtube.tv")
                ?: packageManager.getLaunchIntentForPackage("com.google.android.youtube")
            if (intent != null) {
                startActivity(intent)
            } else {
                // Fallback to Play Store or web
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.youtube.tv")))
                } catch (e: Exception) {
                    Toast.makeText(this, getString(R.string.youtube_not_installed), Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, getString(R.string.youtube_not_installed), Toast.LENGTH_LONG).show()
        }
    }

    private fun openYouTubeVideo(videoId: String) {
        // Supported deep-link / intent for official YouTube
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$videoId"))
        intent.setPackage("com.google.android.youtube.tv")
        try {
            startActivity(intent)
        } catch (e: Exception) {
            // Fallback without package restriction
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$videoId")))
        }
    }
}
