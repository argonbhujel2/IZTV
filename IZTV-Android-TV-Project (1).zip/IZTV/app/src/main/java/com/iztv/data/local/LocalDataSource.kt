package com.iztv.data.local

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.iztv.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStreamReader

class LocalDataSource(private val context: Context) {

    private val gson = Gson()

    suspend fun loadChannels(): List<Channel> = withContext(Dispatchers.IO) {
        readAsset("channels.json")
    }

    suspend fun loadCategories(): List<Category> = withContext(Dispatchers.IO) {
        readAsset("categories.json")
    }

    suspend fun loadEpg(): List<EpgEntry> = withContext(Dispatchers.IO) {
        readAsset("epg.json")
    }

    suspend fun loadMovies(): List<Movie> = withContext(Dispatchers.IO) {
        readAsset("movies.json")
    }

    suspend fun loadSeries(): List<Series> = withContext(Dispatchers.IO) {
        readAsset("series.json")
    }

    private inline fun <reified T> readAsset(filename: String): T {
        context.assets.open(filename).use { input ->
            val type = object : TypeToken<T>() {}.type
            return gson.fromJson(InputStreamReader(input), type)
        }
    }
}
