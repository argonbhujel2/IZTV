package com.iztv.data.repository

import android.content.Context
import com.iztv.data.local.LocalDataSource
import com.iztv.model.*
import com.iztv.network.NetworkModule
import com.iztv.utils.Prefs

/**
 * Single source of truth.
 * Switches between local mock JSON and remote IZ TV API without UI changes.
 */
class ContentRepository(private val context: Context) {

    private val local = LocalDataSource(context)
    private val prefs = Prefs(context)

    private fun api() = NetworkModule.createApiService(prefs.apiBaseUrl)

    suspend fun getChannels(): List<Channel> {
        return if (prefs.useRemoteApi) {
            try {
                api().getChannels()
            } catch (e: Exception) {
                local.loadChannels()
            }
        } else {
            local.loadChannels()
        }
    }

    suspend fun getCategories(): List<Category> {
        return if (prefs.useRemoteApi) {
            try {
                api().getCategories()
            } catch (e: Exception) {
                local.loadCategories()
            }
        } else {
            local.loadCategories()
        }
    }

    suspend fun getEpg(): List<EpgEntry> {
        return if (prefs.useRemoteApi) {
            try {
                api().getEpg()
            } catch (e: Exception) {
                local.loadEpg()
            }
        } else {
            local.loadEpg()
        }
    }

    suspend fun getMovies(): List<Movie> {
        return if (prefs.useRemoteApi) {
            try {
                api().getMovies()
            } catch (e: Exception) {
                local.loadMovies()
            }
        } else {
            local.loadMovies()
        }
    }

    suspend fun getSeries(): List<Series> {
        return if (prefs.useRemoteApi) {
            try {
                api().getSeries()
            } catch (e: Exception) {
                local.loadSeries()
            }
        } else {
            local.loadSeries()
        }
    }
}
