package com.iztv.player

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.iztv.R

class PlayerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_URL = "stream_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_CHANNEL_ID = "channel_id"
        const val EXTRA_CHANNEL_IDS = "channel_ids"
        const val EXTRA_CHANNEL_URLS = "channel_urls"
        const val EXTRA_CHANNEL_NAMES = "channel_names"
    }

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var titleText: TextView
    private lateinit var statusText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var overlay: View

    private var channelIds: List<Int> = emptyList()
    private var channelUrls: List<String> = emptyList()
    private var channelNames: List<String> = emptyList()
    private var currentIndex = 0

    private val hideHandler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { overlay.visibility = View.GONE }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        playerView = findViewById(R.id.playerView)
        titleText = findViewById(R.id.playerTitle)
        statusText = findViewById(R.id.playerStatus)
        progress = findViewById(R.id.playerProgress)
        overlay = findViewById(R.id.playerOverlay)

        val url = intent.getStringExtra(EXTRA_URL) ?: return finish()
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "IZ TV"
        titleText.text = title

        channelIds = intent.getIntegerArrayListExtra(EXTRA_CHANNEL_IDS) ?: emptyList()
        channelUrls = intent.getStringArrayListExtra(EXTRA_CHANNEL_URLS) ?: emptyList()
        channelNames = intent.getStringArrayListExtra(EXTRA_CHANNEL_NAMES) ?: emptyList()
        val startId = intent.getIntExtra(EXTRA_CHANNEL_ID, -1)
        currentIndex = channelIds.indexOf(startId).coerceAtLeast(0)

        initializePlayer(url)
    }

    private fun initializePlayer(url: String) {
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(url))
            exo.prepare()
            exo.playWhenReady = true

            exo.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    when (state) {
                        Player.STATE_BUFFERING -> {
                            progress.visibility = View.VISIBLE
                            statusText.text = getString(R.string.buffering)
                            showOverlay()
                        }
                        Player.STATE_READY -> {
                            progress.visibility = View.GONE
                            statusText.text = ""
                            scheduleHide()
                        }
                        Player.STATE_ENDED -> {
                            progress.visibility = View.GONE
                        }
                        Player.STATE_IDLE -> {}
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    progress.visibility = View.GONE
                    statusText.text = getString(R.string.stream_unavailable)
                    showOverlay()
                }
            })
        }
    }

    private fun showOverlay() {
        overlay.visibility = View.VISIBLE
        hideHandler.removeCallbacks(hideRunnable)
    }

    private fun scheduleHide() {
        hideHandler.removeCallbacks(hideRunnable)
        hideHandler.postDelayed(hideRunnable, 4000)
    }

    private fun switchChannel(delta: Int) {
        if (channelUrls.isEmpty()) return
        currentIndex = (currentIndex + delta + channelUrls.size) % channelUrls.size
        val url = channelUrls[currentIndex]
        val name = channelNames.getOrElse(currentIndex) { "Channel" }
        titleText.text = name
        player?.setMediaItem(MediaItem.fromUri(url))
        player?.prepare()
        player?.playWhenReady = true
        showOverlay()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> {
                switchChannel(1)
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> {
                switchChannel(-1)
                return true
            }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                player?.let {
                    if (it.isPlaying) it.pause() else it.play()
                }
                showOverlay()
                scheduleHide()
                return true
            }
            KeyEvent.KEYCODE_BACK -> {
                finish()
                return true
            }
        }
        showOverlay()
        scheduleHide()
        return super.onKeyDown(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        hideHandler.removeCallbacks(hideRunnable)
        player?.release()
        player = null
        super.onDestroy()
    }
}
