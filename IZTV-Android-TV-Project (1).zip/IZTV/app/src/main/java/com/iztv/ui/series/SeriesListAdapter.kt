package com.iztv.ui.series

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.iztv.R
import com.iztv.model.Series

class SeriesListAdapter(
    private val items: List<Series>,
    private val onClick: (Series) -> Unit
) : RecyclerView.Adapter<SeriesListAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.chName)
        val meta: TextView = v.findViewById(R.id.chCategory)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = items[position]
        holder.title.text = s.title
        holder.meta.text = "${s.seasons.size} seasons"
        holder.itemView.setOnClickListener { onClick(s) }
        holder.itemView.isFocusable = true
    }

    override fun getItemCount() = items.size
}
