package com.iztv.ui.epg

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iztv.R
import com.iztv.data.repository.ContentRepository
import com.iztv.model.EpgEntry
import kotlinx.coroutines.launch

class EpgActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_epg)

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }

        val recycler = findViewById<RecyclerView>(R.id.epgRecycler)
        lifecycleScope.launch {
            val epg = ContentRepository(this@EpgActivity).getEpg()
            recycler.layoutManager = LinearLayoutManager(this@EpgActivity)
            recycler.adapter = EpgAdapter(epg)
        }
    }
}
