package com.iztv.ui.series

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iztv.R
import com.iztv.data.repository.ContentRepository
import com.iztv.model.Series
import com.iztv.player.PlayerActivity
import kotlinx.coroutines.launch

class SeriesActivity : AppCompatActivity() {

    private lateinit var seriesRecycler: RecyclerView
    private lateinit var episodeRecycler: RecyclerView
    private var seriesList: List<Series> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_series)

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }
        seriesRecycler = findViewById(R.id.seriesRecycler)
        episodeRecycler = findViewById(R.id.episodeRecycler)

        lifecycleScope.launch {
            seriesList = ContentRepository(this@SeriesActivity).getSeries()
            seriesRecycler.layoutManager = LinearLayoutManager(this@SeriesActivity)
            seriesRecycler.adapter = SeriesListAdapter(seriesList) { series ->
                showEpisodes(series)
            }
            if (seriesList.isNotEmpty()) showEpisodes(seriesList[0])
        }
    }

    private fun showEpisodes(series: Series) {
        val episodes = series.seasons.flatMap { it.episodes }
        episodeRecycler.layoutManager = LinearLayoutManager(this)
        episodeRecycler.adapter = EpisodeAdapter(episodes) { ep ->
            val intent = Intent(this, PlayerActivity::class.java)
            intent.putExtra(PlayerActivity.EXTRA_URL, ep.streamUrl)
            intent.putExtra(PlayerActivity.EXTRA_TITLE, ep.title)
            startActivity(intent)
        }
    }
}
