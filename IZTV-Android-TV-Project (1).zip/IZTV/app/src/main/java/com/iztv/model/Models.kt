package com.iztv.model

import com.google.gson.annotations.SerializedName

data class Channel(
    val id: Int,
    val name: String,
    val category: String,
    val type: String = "hls",
    val streamUrl: String,
    val logoUrl: String = "",
    val enabled: Boolean = true,
    val number: Int = 0
)

data class Category(
    val id: Int,
    val name: String,
    val slug: String
)

data class Program(
    val start: String,
    val end: String,
    val title: String,
    val description: String = ""
)

data class EpgEntry(
    val channelId: Int,
    val channelName: String,
    val programs: List<Program>
)

data class Movie(
    val id: Int,
    val title: String,
    val year: Int,
    val duration: String,
    val description: String,
    val category: String,
    val posterUrl: String = "",
    val streamUrl: String,
    val featured: Boolean = false
)

data class Episode(
    val id: Int,
    val title: String,
    val description: String,
    val duration: String,
    val thumbnailUrl: String = "",
    val streamUrl: String
)

data class Season(
    val seasonNumber: Int,
    val episodes: List<Episode>
)

data class Series(
    val id: Int,
    val title: String,
    val description: String,
    val posterUrl: String = "",
    val seasons: List<Season>
)

data class ContinueWatchingItem(
    val id: String,
    val title: String,
    val type: String, // "movie", "episode", "channel"
    val posterUrl: String = "",
    val progress: Float = 0f,
    val streamUrl: String = ""
)
