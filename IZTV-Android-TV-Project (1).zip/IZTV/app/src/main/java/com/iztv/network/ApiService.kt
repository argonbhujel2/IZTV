package com.iztv.network

import com.iztv.model.*
import retrofit2.http.GET
import retrofit2.http.Path

/**
 * Future IZ TV backend endpoints.
 * Currently the app uses local mock data.
 * Switch via Prefs.useRemoteApi when backend is ready.
 */
interface ApiService {

    @GET("api/channels")
    suspend fun getChannels(): List<Channel>

    @GET("api/categories")
    suspend fun getCategories(): List<Category>

    @GET("api/epg")
    suspend fun getEpg(): List<EpgEntry>

    @GET("api/movies")
    suspend fun getMovies(): List<Movie>

    @GET("api/series")
    suspend fun getSeries(): List<Series>

    @GET("api/device/{deviceId}")
    suspend fun getDeviceStatus(@Path("deviceId") deviceId: String): Map<String, Any>

    @GET("api/config")
    suspend fun getConfig(): Map<String, Any>
}
