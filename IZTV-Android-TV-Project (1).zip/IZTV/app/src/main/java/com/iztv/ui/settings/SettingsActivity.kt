package com.iztv.ui.settings

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.iztv.R
import com.iztv.utils.DeviceUtils

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<TextView>(R.id.btnDeviceInfo).setOnClickListener {
            val info = """
                Model: ${DeviceUtils.getDeviceModel()}
                Android: ${DeviceUtils.getAndroidVersion()}
                App: ${DeviceUtils.getAppVersion(this)}
                Device ID: ${DeviceUtils.getOrCreateDeviceId(this)}
                Resolution: ${DeviceUtils.getScreenResolution(this)}
            """.trimIndent()
            Toast.makeText(this, info, Toast.LENGTH_LONG).show()
        }

        findViewById<TextView>(R.id.btnTestMode).setOnClickListener {
            startActivity(Intent(this, TestModeActivity::class.java))
        }

        findViewById<TextView>(R.id.btnClearCache).setOnClickListener {
            // Simple cache clear placeholder
            Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show()
        }

        findViewById<TextView>(R.id.btnReload).setOnClickListener {
            Toast.makeText(this, "Content will reload on next open", Toast.LENGTH_SHORT).show()
        }

        findViewById<TextView>(R.id.btnAppInfo).setOnClickListener {
            Toast.makeText(this, "IZ TV v${DeviceUtils.getAppVersion(this)}\nPrototype for ISP testing", Toast.LENGTH_LONG).show()
        }
    }
}
