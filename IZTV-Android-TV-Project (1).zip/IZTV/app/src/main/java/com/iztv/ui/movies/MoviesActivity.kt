package com.iztv.ui.movies

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iztv.R
import com.iztv.data.repository.ContentRepository
import com.iztv.player.PlayerActivity
import com.iztv.ui.home.FeaturedAdapter
import kotlinx.coroutines.launch

class MoviesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movies)

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }

        val recycler = findViewById<RecyclerView>(R.id.moviesRecycler)
        lifecycleScope.launch {
            val movies = ContentRepository(this@MoviesActivity).getMovies()
            recycler.layoutManager = GridLayoutManager(this@MoviesActivity, 4)
            recycler.adapter = FeaturedAdapter(movies) { movie ->
                val intent = Intent(this@MoviesActivity, PlayerActivity::class.java)
                intent.putExtra(PlayerActivity.EXTRA_URL, movie.streamUrl)
                intent.putExtra(PlayerActivity.EXTRA_TITLE, movie.title)
                startActivity(intent)
            }
        }
    }
}
