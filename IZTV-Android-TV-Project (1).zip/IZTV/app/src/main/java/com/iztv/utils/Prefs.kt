package com.iztv.utils

import android.content.Context
import android.content.SharedPreferences

class Prefs(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("iztv_settings", Context.MODE_PRIVATE)

    var apiBaseUrl: String
        get() = prefs.getString(KEY_API_URL, DEFAULT_API) ?: DEFAULT_API
        set(value) = prefs.edit().putString(KEY_API_URL, value).apply()

    var testHlsUrl: String
        get() = prefs.getString(KEY_TEST_HLS, DEFAULT_HLS) ?: DEFAULT_HLS
        set(value) = prefs.edit().putString(KEY_TEST_HLS, value).apply()

    var youtubeVideoId: String
        get() = prefs.getString(KEY_YT_ID, "") ?: ""
        set(value) = prefs.edit().putString(KEY_YT_ID, value).apply()

    var useRemoteApi: Boolean
        get() = prefs.getBoolean(KEY_USE_REMOTE, false)
        set(value) = prefs.edit().putBoolean(KEY_USE_REMOTE, value).apply()

    companion object {
        private const val KEY_API_URL = "api_base_url"
        private const val KEY_TEST_HLS = "test_hls_url"
        private const val KEY_YT_ID = "youtube_video_id"
        private const val KEY_USE_REMOTE = "use_remote_api"
        private const val DEFAULT_API = "https://api.iztv.example.com"
        // Public authorized test streams only
        private const val DEFAULT_HLS = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    }
}
