package com.iztv.ui.splash

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.iztv.R
import com.iztv.ui.home.HomeActivity
import com.iztv.utils.DeviceUtils

class SplashActivity : AppCompatActivity() {

    private lateinit var progress: ProgressBar
    private lateinit var statusText: TextView
    private lateinit var retryButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        progress = findViewById(R.id.splashProgress)
        statusText = findViewById(R.id.splashStatus)
        retryButton = findViewById(R.id.btnRetry)

        retryButton.setOnClickListener {
            retryButton.visibility = View.GONE
            progress.visibility = View.VISIBLE
            statusText.text = getString(R.string.checking_network)
            checkAndProceed()
        }

        // Initial delay for logo visibility
        Handler(Looper.getMainLooper()).postDelayed({
            statusText.text = getString(R.string.checking_network)
            checkAndProceed()
        }, 1200)
    }

    private fun checkAndProceed() {
        if (DeviceUtils.isNetworkAvailable(this)) {
            statusText.text = getString(R.string.connected)
            Handler(Looper.getMainLooper()).postDelayed({
                startActivity(Intent(this, HomeActivity::class.java))
                finish()
            }, 600)
        } else {
            progress.visibility = View.GONE
            statusText.text = getString(R.string.no_internet)
            retryButton.visibility = View.VISIBLE
            retryButton.requestFocus()
        }
    }
}
