package com.iztv.ui.home

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.iztv.R
import com.iztv.model.Movie

class FeaturedAdapter(
    private val items: List<Movie>,
    private val onClick: (Movie) -> Unit
) : RecyclerView.Adapter<FeaturedAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.cardTitle)
        val meta: TextView = view.findViewById(R.id.cardMeta)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_content_card, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.title.text = item.title
        holder.meta.text = "${item.year} • ${item.duration}"
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.isFocusable = true
        holder.itemView.isClickable = true
    }

    override fun getItemCount(): Int = items.size
}
