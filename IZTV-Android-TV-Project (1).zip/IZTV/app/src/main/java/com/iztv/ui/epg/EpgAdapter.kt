package com.iztv.ui.epg

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.iztv.R
import com.iztv.model.EpgEntry

class EpgAdapter(private val items: List<EpgEntry>) : RecyclerView.Adapter<EpgAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val channel: TextView = v.findViewById(R.id.epgChannel)
        val programs: TextView = v.findViewById(R.id.epgPrograms)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_epg, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        holder.channel.text = e.channelName
        val progText = e.programs.joinToString("\n") {
            "${it.start} - ${it.end}  ${it.title}"
        }
        holder.programs.text = progText
        holder.itemView.isFocusable = true
    }

    override fun getItemCount() = items.size
}
