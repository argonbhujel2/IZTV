package com.iztv

import android.app.Application
import com.iztv.utils.DeviceUtils

class IZTVApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Ensure device ID exists early
        DeviceUtils.getOrCreateDeviceId(this)
    }
}
