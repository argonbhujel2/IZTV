package com.iztv.ui.home

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iztv.R
import com.iztv.data.repository.ContentRepository
import com.iztv.model.Movie
import com.iztv.ui.epg.EpgActivity
import com.iztv.ui.livetv.LiveTvActivity
import com.iztv.ui.movies.MoviesActivity
import com.iztv.ui.series.SeriesActivity
import com.iztv.ui.settings.SettingsActivity
import com.iztv.ui.youtube.YouTubeActivity
import com.iztv.utils.DeviceUtils
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HomeActivity : AppCompatActivity() {

    private lateinit var clockText: TextView
    private lateinit var statusText: TextView
    private lateinit var featuredRecycler: RecyclerView
    private lateinit var continueRecycler: RecyclerView
    private val handler = Handler(Looper.getMainLooper())
    private val clockRunnable = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 30000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        clockText = findViewById(R.id.homeClock)
        statusText = findViewById(R.id.homeStatus)
        featuredRecycler = findViewById(R.id.featuredRecycler)
        continueRecycler = findViewById(R.id.continueRecycler)

        setupNavButtons()
        setupClockAndStatus()
        loadFeatured()

        // Request focus on first nav item
        findViewById<TextView>(R.id.navLiveTv).requestFocus()
    }

    private fun setupNavButtons() {
        findViewById<TextView>(R.id.navLiveTv).setOnClickListener {
            startActivity(Intent(this, LiveTvActivity::class.java))
        }
        findViewById<TextView>(R.id.navYoutube).setOnClickListener {
            startActivity(Intent(this, YouTubeActivity::class.java))
        }
        findViewById<TextView>(R.id.navMovies).setOnClickListener {
            startActivity(Intent(this, MoviesActivity::class.java))
        }
        findViewById<TextView>(R.id.navSeries).setOnClickListener {
            startActivity(Intent(this, SeriesActivity::class.java))
        }
        findViewById<TextView>(R.id.navEpg).setOnClickListener {
            startActivity(Intent(this, EpgActivity::class.java))
        }
        findViewById<TextView>(R.id.navSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun setupClockAndStatus() {
        updateClock()
        statusText.text = if (DeviceUtils.isNetworkAvailable(this)) {
            "● ${getString(R.string.connected)}"
        } else {
            "○ ${getString(R.string.disconnected)}"
        }
        handler.post(clockRunnable)
    }

    private fun updateClock() {
        val sdf = SimpleDateFormat("h:mm a", Locale.getDefault())
        clockText.text = sdf.format(Date())
    }

    private fun loadFeatured() {
        lifecycleScope.launch {
            val repo = ContentRepository(this@HomeActivity)
            val movies = repo.getMovies().filter { it.featured }
            featuredRecycler.layoutManager =
                LinearLayoutManager(this@HomeActivity, LinearLayoutManager.HORIZONTAL, false)
            featuredRecycler.adapter = FeaturedAdapter(movies) { movie ->
                // Open player with movie stream
                val intent = Intent(this@HomeActivity, com.iztv.player.PlayerActivity::class.java)
                intent.putExtra(com.iztv.player.PlayerActivity.EXTRA_URL, movie.streamUrl)
                intent.putExtra(com.iztv.player.PlayerActivity.EXTRA_TITLE, movie.title)
                startActivity(intent)
            }

            // Simple continue watching placeholders from movies
            continueRecycler.layoutManager =
                LinearLayoutManager(this@HomeActivity, LinearLayoutManager.HORIZONTAL, false)
            continueRecycler.adapter = FeaturedAdapter(movies.take(4)) { movie ->
                val intent = Intent(this@HomeActivity, com.iztv.player.PlayerActivity::class.java)
                intent.putExtra(com.iztv.player.PlayerActivity.EXTRA_URL, movie.streamUrl)
                intent.putExtra(com.iztv.player.PlayerActivity.EXTRA_TITLE, movie.title)
                startActivity(intent)
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(clockRunnable)
        super.onDestroy()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        // Allow Back to exit to launcher only from home
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finishAffinity()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
