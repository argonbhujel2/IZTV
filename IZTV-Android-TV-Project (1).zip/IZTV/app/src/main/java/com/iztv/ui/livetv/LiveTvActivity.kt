package com.iztv.ui.livetv

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.iztv.R
import com.iztv.data.repository.ContentRepository
import com.iztv.model.Category
import com.iztv.model.Channel
import com.iztv.player.PlayerActivity
import kotlinx.coroutines.launch

class LiveTvActivity : AppCompatActivity() {

    private lateinit var categoryRecycler: RecyclerView
    private lateinit var channelRecycler: RecyclerView
    private var allChannels: List<Channel> = emptyList()
    private var currentCategory: String = "All"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live_tv)

        categoryRecycler = findViewById(R.id.categoryRecycler)
        channelRecycler = findViewById(R.id.channelRecycler)

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }

        loadData()
    }

    private fun loadData() {
        lifecycleScope.launch {
            val repo = ContentRepository(this@LiveTvActivity)
            val categories = repo.getCategories()
            allChannels = repo.getChannels().filter { it.enabled }

            categoryRecycler.layoutManager =
                LinearLayoutManager(this@LiveTvActivity, LinearLayoutManager.HORIZONTAL, false)
            categoryRecycler.adapter = CategoryAdapter(categories) { cat ->
                currentCategory = cat.name
                filterChannels()
            }

            filterChannels()
            // Focus first channel after short delay
            channelRecycler.post {
                channelRecycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
            }
        }
    }

    private fun filterChannels() {
        val filtered = if (currentCategory == "All") {
            allChannels
        } else {
            allChannels.filter { it.category.equals(currentCategory, ignoreCase = true) }
        }
        channelRecycler.layoutManager = LinearLayoutManager(this)
        channelRecycler.adapter = ChannelAdapter(filtered) { channel ->
            openPlayer(channel)
        }
    }

    private fun openPlayer(channel: Channel) {
        val intent = Intent(this, PlayerActivity::class.java)
        intent.putExtra(PlayerActivity.EXTRA_URL, channel.streamUrl)
        intent.putExtra(PlayerActivity.EXTRA_TITLE, channel.name)
        intent.putExtra(PlayerActivity.EXTRA_CHANNEL_ID, channel.id)
        // Pass all channels for channel up/down
        intent.putIntegerArrayListExtra(
            PlayerActivity.EXTRA_CHANNEL_IDS,
            ArrayList(allChannels.map { it.id })
        )
        intent.putStringArrayListExtra(
            PlayerActivity.EXTRA_CHANNEL_URLS,
            ArrayList(allChannels.map { it.streamUrl })
        )
        intent.putStringArrayListExtra(
            PlayerActivity.EXTRA_CHANNEL_NAMES,
            ArrayList(allChannels.map { it.name })
        )
        startActivity(intent)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            finish()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
