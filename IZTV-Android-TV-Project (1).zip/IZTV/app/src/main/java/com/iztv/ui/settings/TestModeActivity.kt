package com.iztv.ui.settings

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.iztv.R
import com.iztv.player.PlayerActivity
import com.iztv.utils.DeviceUtils
import com.iztv.utils.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

class TestModeActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var etApi: EditText
    private lateinit var etHls: EditText
    private lateinit var etYt: EditText
    private lateinit var tvDeviceId: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test_mode)

        prefs = Prefs(this)
        etApi = findViewById(R.id.etApiUrl)
        etHls = findViewById(R.id.etHlsUrl)
        etYt = findViewById(R.id.etYtId)
        tvDeviceId = findViewById(R.id.tvDeviceId)

        etApi.setText(prefs.apiBaseUrl)
        etHls.setText(prefs.testHlsUrl)
        etYt.setText(prefs.youtubeVideoId)
        tvDeviceId.text = DeviceUtils.getOrCreateDeviceId(this)

        findViewById<TextView>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<Button>(R.id.btnSave).setOnClickListener {
            prefs.apiBaseUrl = etApi.text.toString().trim()
            prefs.testHlsUrl = etHls.text.toString().trim()
            prefs.youtubeVideoId = etYt.text.toString().trim()
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnTestStream).setOnClickListener {
            val url = etHls.text.toString().trim()
            if (url.isNotBlank()) {
                val intent = Intent(this, PlayerActivity::class.java)
                intent.putExtra(PlayerActivity.EXTRA_URL, url)
                intent.putExtra(PlayerActivity.EXTRA_TITLE, "Test Stream")
                startActivity(intent)
            }
        }

        findViewById<Button>(R.id.btnTestNetwork).setOnClickListener {
            val ok = DeviceUtils.isNetworkAvailable(this)
            Toast.makeText(this, if (ok) "Network OK" else "No network", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnTestApi).setOnClickListener {
            val base = etApi.text.toString().trim()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val conn = URL("$base/api/config").openConnection() as HttpURLConnection
                    conn.connectTimeout = 5000
                    conn.readTimeout = 5000
                    conn.requestMethod = "GET"
                    val code = conn.responseCode
                    runOnUiThread {
                        Toast.makeText(this@TestModeActivity, "API response: $code", Toast.LENGTH_LONG).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this@TestModeActivity, "API error: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        findViewById<Button>(R.id.btnReloadChannels).setOnClickListener {
            Toast.makeText(this, "Channels will reload from current source", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnClearCache).setOnClickListener {
            Toast.makeText(this, "Cache cleared", Toast.LENGTH_SHORT).show()
        }
    }
}
