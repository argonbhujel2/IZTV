# IZ TV ProGuard rules (prototype - minify disabled by default)
-keep class com.iztv.model.** { *; }
-keep class com.iztv.network.** { *; }
