# IZ TV – Android TV IPTV Prototype

**Professional ISP-style Android TV application**  
Package: `com.iztv`  
Version: 1.0.0-prototype

This is a complete, original, from-scratch Android TV project.  
It uses **only authorized public test HLS streams** and mock data.  
No commercial TV channel streams are included.

---

## 1. Project Structure

```
IZTV/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── assets/
│       │   ├── channels.json
│       │   ├── categories.json
│       │   ├── epg.json
│       │   ├── movies.json
│       │   └── series.json
│       ├── java/com/iztv/
│       │   ├── IZTVApplication.kt
│       │   ├── model/Models.kt
│       │   ├── data/
│       │   │   ├── local/LocalDataSource.kt
│       │   │   └── repository/ContentRepository.kt
│       │   ├── network/
│       │   │   ├── ApiService.kt
│       │   │   └── NetworkModule.kt
│       │   ├── player/PlayerActivity.kt
│       │   ├── ui/
│       │   │   ├── splash/SplashActivity.kt
│       │   │   ├── home/...
│       │   │   ├── livetv/...
│       │   │   ├── youtube/...
│       │   │   ├── movies/...
│       │   │   ├── series/...
│       │   │   ├── epg/...
│       │   │   └── settings/...
│       │   └── utils/...
│       └── res/
│           ├── drawable/
│           ├── layout/
│           ├── values/
│           └── mipmap-*/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── gradle/wrapper/
```

---

## 2. Setup Instructions

1. Install **Android Studio** (Hedgehog / Iguana or newer recommended).
2. Open the `IZTV` folder as an existing project.
3. Let Gradle sync (it will download dependencies).
4. Connect an Android TV device / emulator or use an X96 Max box via ADB.

**Minimum requirements**
- minSdk 21
- targetSdk 34
- Kotlin 1.9+
- Android Gradle Plugin 8.2+

---

## 3. Dependencies (already in `app/build.gradle.kts`)

- AndroidX Core / AppCompat / Material
- Leanback (TV)
- Media3 / ExoPlayer + HLS
- Retrofit + OkHttp + Gson
- Kotlin Coroutines
- Glide
- Navigation, Lifecycle, ViewModel

---

## 4. Build Commands

### Debug APK
```bash
cd IZTV
./gradlew assembleDebug
```
Output:  
`app/build/outputs/apk/debug/app-debug.apk`

### Release APK (unsigned)
```bash
./gradlew assembleRelease
```
Output:  
`app/build/outputs/apk/release/app-release-unsigned.apk`

### Rename to IZ-TV.apk
```bash
cp app/build/outputs/apk/debug/app-debug.apk IZ-TV.apk
```

> Note: On first open Android Studio may ask to create the Gradle Wrapper. Accept it.

---

## 5. APK Output Location

After a successful build:
```
IZTV/app/build/outputs/apk/debug/app-debug.apk
```
or
```
IZTV/app/build/outputs/apk/release/app-release-unsigned.apk
```

---

## 6. USB Installation on X96 Max-type Box

1. Copy `IZ-TV.apk` to a USB drive.
2. Insert USB into the TV box.
3. Open **File Manager** (or ES File Explorer / X-plore).
4. Navigate to the USB drive.
5. Select `IZ-TV.apk` → Install.
6. Allow “Install from unknown sources” if prompted.
7. Open **IZ TV** from the Apps list or Leanback launcher.

---

## 7. ADB Installation (alternative)

```bash
# Enable ADB debugging on the box (Developer options)
adb connect <BOX_IP>:5555
adb install -r IZ-TV.apk
adb shell am start -n com.iztv/.ui.splash.SplashActivity
```

---

## 8. Test Procedure – Live TV

1. Launch IZ TV → Splash → Home.
2. Select **LIVE TV** (D-pad + OK).
3. Choose a category (All / News / Sports …).
4. Select **IZ Test TV** or any demo channel.
5. Player opens with public test HLS stream.
6. Use **D-pad Up / Down** for Channel Up / Down.
7. **OK / Play-Pause** toggles playback.
8. **Back** returns to channel list.

Public test streams used:
- https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8
- Apple bipbop HLS sample

---

## 9. Test Procedure – YouTube

1. From Home select **YOUTUBE**.
2. Press **Open YouTube App**.
3. If official YouTube TV / YouTube is installed → it launches.
4. Otherwise a message is shown.
5. Optionally set a Video ID in **Settings → Test Mode** and use “Open Test Video”.

No scraping, no unauthorized stream extraction.

---

## 10. Troubleshooting Guide

| Problem | Solution |
|---------|----------|
| App not appearing on launcher | Ensure Leanback category is present (already in Manifest). Reboot box. |
| “No Internet” on splash | Check Ethernet/Wi-Fi. Press RETRY. |
| Stream fails / black screen | Confirm the test HLS URL is reachable. Try another demo channel. |
| Focus not moving | All interactive views are focusable. Use D-pad only. |
| YouTube not launching | Install official YouTube for Android TV from Play Store. |
| Build fails on first sync | Accept Gradle wrapper creation. Use JDK 17. |
| Sideload blocked | Enable “Unknown sources” / “Install via USB” in Settings. |
| Low performance on X96 Max | App is already optimized (no heavy services, lazy lists, Media3 hardware decoding). Close other apps. |

---

## Architecture Notes

- **Local mock JSON** → works offline for UI testing.
- **ContentRepository** can switch to remote API (`Prefs.useRemoteApi = true`) without changing any UI code.
- Future endpoints prepared: `/api/channels`, `/api/epg`, `/api/movies`, `/api/series`, `/api/device/{id}`, `/api/config`.
- Device ID is a random UUID stored in SharedPreferences (no personal data collected).
- All streams are publicly authorized test streams only.

---

## Legal / Testing Limit

This is a **prototype**.  
Use only your own authorized streams or public test streams.  
Do not hardcode copyrighted commercial television channels.

---

**IZ TV** – Original branding and UI.  
Ready for ISP-style backend integration.
